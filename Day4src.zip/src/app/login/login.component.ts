import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  onSubmit(user:any){
    if(user['uname']=='abhishek' && user['pass']=='12345'){
      alert('login success')
      sessionStorage.setItem('user',user['uname']);
    }
    else{
      alert('login failure')
    }
  }
  logout(){
    sessionStorage.removeItem('user');
  }
}
