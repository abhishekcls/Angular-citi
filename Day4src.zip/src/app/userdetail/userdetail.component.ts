import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {
  id:string;
  user:any;
  constructor(ar:ActivatedRoute,us:UserService) { 
    this.id=ar.snapshot.params['id'];

    us.getUserById(this.id).subscribe(u=>this.user=u);
  }

  ngOnInit(): void {
  }

}
