import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-bookdetail',
  templateUrl: './bookdetail.component.html',
  styleUrls: ['./bookdetail.component.css']
})
export class BookdetailComponent implements OnInit {

  id:string;
  constructor(ar:ActivatedRoute) { 
    this.id=ar.snapshot.params['id'];
  }

  ngOnInit(): void {
  }

}
