import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})
export class RformComponent implements OnInit {
  emprform:FormGroup;
  constructor() { 
    this.emprform=new FormGroup({
      eid:new FormControl('',this.empIdValidator),
      ename:new FormControl('',Validators.compose(
        [Validators.required,Validators.pattern('[a-zA-Z]{2,10}')]) )
    });
  }

  onSubmit(data:any){
    console.log(data);
  }

  empIdValidator(c:any){
    if(c.value.trim().length==0){
      return null
    }

    let eid=parseInt(c.value)
    let min=101;
    let max=130;

    if(eid>=min && eid<=max){
      return null
    }
    else{
      return {'customeid':{'min':min,'max':max}}
    }
  }

  ngOnInit(): void {
  }

}
