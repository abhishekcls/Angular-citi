import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:'gender'
})
export class GenderPipe implements PipeTransform{
    transform(g:string):string{
        let res='Male';
        if(g=='F')
            res='Female'
        return res;
    }
}

//Task: TaxPipe