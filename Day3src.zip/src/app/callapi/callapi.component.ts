import { Component, OnInit } from '@angular/core';
import { RestapiService } from '../restapi.service';

@Component({
  selector: 'app-callapi',
  template: `
    <h1>RESTAPI Demo</h1>
    <table border="1">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Company</th>
        <th>City</th>
      </tr>
      <tr *ngFor="let u of users">
        <td>{{u.id}}</td>
        <td>{{u.name}}</td>
        <td>{{u.company.name}}</td>
        <td>{{u.address.city}}</td>
      </tr>
    </table>
  `,
  styles: [
  ]
})
export class CallapiComponent implements OnInit {

  users:any;
  constructor(api:RestapiService)//DI
  { 
    api.getData().subscribe(u=>this.users=u);
  }

  ngOnInit(): void {
  }

}
