import { Pipe, PipeTransform } from "@angular/core";

@Pipe({name:'tax'})
export class TaxPipe implements PipeTransform{
    transform(sal:number,rate:number=0.1):number {
        return sal*rate;
    }
}