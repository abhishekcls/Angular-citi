import { Component } from "@angular/core";

@Component({
    selector:'tform',
    template:`
    <h1>Hello {{name}}</h1>
    <form #empform="ngForm" (ngSubmit)="onSubmit(empform.value)">
        <input type="text" placeholder="eid" name="eid" ngModel required/>*<br/>
        <input type="text" placeholder="ename" name="ename" [(ngModel)]="name"/><br/>
        <input type="submit" [disabled]="empform.invalid"/>
    </form>
    `
})
export class TformComponent{
    name:string='Abhishek';
    onSubmit(data:any){
        console.log(data);
    }
}
//type empData={eid:string,ename:string};