import { Component } from "@angular/core";

@Component({
    selector:'misc',
    template:`
    <h1>Misc</h1>
    <img src="https://hdsmileys.com/wp-content/uploads/2017/11/blush.gif"/>
    <img src="{{path}}"/>
    <img [src]="path"/>
    <img bind-src="path"/>

    <img src="{{basepath}}lol.gif"/>
    <img src="{{basepath}}cry.gif"/>

    <button (click)="show()" disabled="{{flag}}">click1</button>
    <button on-click="show()" [disabled]="flag">click2</button>
    `
})
export class MiscComponent{
    flag:boolean=false;
    path:string="https://hdsmileys.com/wp-content/uploads/2017/11/blush.gif";
    basepath="https://hdsmileys.com/wp-content/uploads/2017/11/";

    show(){
        alert("Hello");
    }
}