import { Component } from "@angular/core";

@Component({
    selector:'app',
    template:`<h1>First Angular{{ver}} App by {{name}}</h1>
    <!-- <app-callapi></app-callapi> -->
    <app-rform></app-rform>
    <misc>Loading...</misc>
    <tform>Wait...</tform>
    {{games}}
    <ol>
        <li *ngFor="let g of games">{{g}}</li>
    </ol>
    {{emp.eid + " " + emp.ename}}
    {{emp.eid}} {{emp.ename}}
    {{emp | json}}
    
    <table border="1">
        <tr *ngFor="let e of emps">
            <td>{{e.eid}}</td>
            <td>{{e.ename }}</td>
            <td>{{e.ename | uppercase }} </td>
            <td>{{e.ename | uppercase | slice:2}}</td>
            <td>{{e.ename | lowercase}}</td>
            <td>{{e.ename | slice:2}}</td>
            <td>{{e.ename | slice:2:4}}</td>
            <td>{{e.gender | gender}}</td>
            <td>{{e.sal}}</td>
            <td>{{e.sal | number}}</td>
            <td>{{e.sal | currency}}</td>
            <td>{{e.sal | currency:'EUR'}}</td>
            <td>{{e.sal | currency:'INR'}}</td>
            <td>{{e.sal | tax:0.2 }}</td>
            <td>{{e.sal | tax | currency:'INR'}}</td>
            <td>{{e.retired}}</td>
            <td>{{e.doj | date}}</td>
            <td>{{e.doj | date:'d/M/y'}}</td>
            <td>
                <img *ngIf="e.retired; else working" height="75" width="75" src="https://i.pinimg.com/originals/00/f5/75/00f575172b157cdf22d325b2dd10edb2.gif"/>
                
                <ng-template #working>
                <img height="75" width="75" src="https://c.tenor.com/vM2hP3AsiP8AAAAM/%E0%A4%87%E0%A4%AE%E0%A5%8B%E0%A4%9C%E0%A5%80-%E0%A4%B0%E0%A5%8B%E0%A4%A8%E0%A4%BE.gif"/>
                </ng-template>
            </td>
        </tr>
    </table>
    <h2>Something</h2>
    <nested></nested>`
})
export class AppComponent{
    name:string;
    ver:number=13;

    games:string[]=['cricket','hockey','polo'];

    emp={'eid':100,'ename':'Deepak'}

    emps=[
        {'eid':101,'ename':'Tarun','gender':'M','sal':45000,'retired':false,'doj':new Date("1995-05-08")},
        {'eid':102,'ename':'Prateek','gender':'M','sal':90000,'retired':true,'doj':new Date("1991-03-02")},
        {'eid':103,'ename':'Kavita','gender':'F','sal':50000,'retired':false,'doj':new Date("2015-03-01")},
        {'eid':104,'ename':'Jatin','gender':'M','sal':70000,'retired':false,'doj':new Date("2004-11-10")},
        {'eid':105,'ename':'Parul','gender':'F','sal':85000,'retired':true,'doj':new Date("1990-02-03")}
    ]

    constructor(){
        this.name='Abhishek Samanta'
    }
}