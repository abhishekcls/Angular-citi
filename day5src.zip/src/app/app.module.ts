import { NgModule } from "@angular/core";
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";
import { AnotherComponent } from "./another.component";
import { NestedComponent } from "./nested.component";
import { GenderPipe } from "./gender.pipe";
import { TaxPipe } from "./tax.pipe";
import { TformComponent } from "./tform.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MiscComponent } from "./misc.component";
import { RformComponent } from './rform/rform.component';
import {HttpClientModule} from '@angular/common/http';
import { CallapiComponent } from './callapi/callapi.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

@NgModule({
    imports:[BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule, ServiceWorkerModule.register('ngsw-worker.js', {
  enabled: environment.production,
  // Register the ServiceWorker as soon as the application is stable
  // or after 30 seconds (whichever comes first).
  registrationStrategy: 'registerWhenStable:30000'
})],
    declarations:[AppComponent,AnotherComponent,NestedComponent,
        TformComponent,MiscComponent,
        GenderPipe,TaxPipe, RformComponent, CallapiComponent],
    bootstrap:[AppComponent,AnotherComponent]
})
export class AppModule{}