import { NgModule } from "@angular/core";
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";
import { AnotherComponent } from "./another.component";
import { NestedComponent } from "./nested.component";
import { GenderPipe } from "./gender.pipe";
import { TaxPipe } from "./tax.pipe";
import { TformComponent } from "./tform.component";
import { FormsModule } from "@angular/forms";
import { MiscComponent } from "./misc.component";

@NgModule({
    imports:[BrowserModule,FormsModule],
    declarations:[AppComponent,AnotherComponent,NestedComponent,
        TformComponent,MiscComponent,
        GenderPipe,TaxPipe],
    bootstrap:[AppComponent,AnotherComponent]
})
export class AppModule{}